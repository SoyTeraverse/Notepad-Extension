# Changelog — Notepad Azure

## 3VS — Major Update (3.0.0)
- Changed the visible release tag from `3.0` to `3VS`.
- Version tag convention: `VS` = Major Update, `HV` = Batch Update, and `V` = Small Update.
- Added text quality preference options: 720p, 1080p, 1440p, and 4K. 8K is listed as currently unavailable. This preference is metadata for future export/rendering features and does not upscale plain text.
- Added Publish button and a Published Notes Gallery stored locally in the Firefox profile. Publishing is local-only, not public web hosting.
- Added templates: Lorem Ipsum, 2006 text style, and 2010 text style.
- Replaced the Collaboration button label with Show Tabs.
- Added multi-tab notes with a maximum of 120 tabs.
- Added Markdown support for notes and code documents, plus Markdown preview and `.md` import/export.
- AI Azure local writing tools remain on-device; external AI service repair requires a configured service and is not represented as a verified online AI fix.
- Notepad Premium pricing announcement: US$5 in the United States and US$3 in other countries, as specified by the project owner. Payment and premium account unlocking are not implemented.

## 2.0.7 — H2.7 Side Update
- Renamed extension to Notepad Azure.
- Added .GHT project import/export, local AI Azure writing tools, Note / Code / HTML Preview modes, Firefox identity, icons, and favicon assets.
- Fixed light/system theme toolbar button visibility.
