# Notepad Azure 3VS (3.0.0) — Firefox

A local-first Firefox note editor with Note, Code, HTML Preview, and Markdown modes.

## 3VS Major Update
- Markdown authoring and safe Markdown preview; `.md` import/export.
- Up to 120 locally saved tabs.
- Publish notes to a gallery stored in the current browser profile (not a public website).
- Lorem Ipsum, 2006-style, and 2010-style templates.
- Text quality preference selector: 720p, 1080p, 1440p, 4K; 8K is currently unavailable. This is a preference placeholder and does not alter plain-text resolution.
- `.GHT` project export/import and local AI Azure writing helpers.

## Version labels
- `VS` = Major Update
- `HV` = Batch Update
- `V` = Small Update

## Install temporarily
1. Extract this ZIP.
2. Open `about:debugging#/runtime/this-firefox`.
3. Choose **Load Temporary Add-on…** and select `manifest.json`.

## Notes
- Published notes remain local to this browser; no public hosting or real-time collaboration service is included.
- Premium pricing is announced as US$5 in the United States and US$3 in other countries, but checkout/unlock functionality is not implemented.
- The 8K option is disabled until supported by a future export/rendering feature.
