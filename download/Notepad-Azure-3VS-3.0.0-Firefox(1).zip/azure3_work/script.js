const $ = (id) => document.getElementById(id);

const noteInput = $("noteInput");
const noteTitle = $("noteTitle");
const charCount = $("charCount");
const wordCount = $("wordCount");
const lineCount = $("lineCount");
const saveText = $("saveText");
const saveIndicator = $("saveIndicator");
const clearBtn = $("clearBtn");
const exportBtn = $("exportBtn");
const importBtn = $("importBtn");
const fileInput = $("fileInput");
const searchBtn = $("searchBtn");
const searchBar = $("searchBar");
const searchInput = $("searchInput");
const searchCount = $("searchCount");
const closeSearchBtn = $("closeSearchBtn");
const settingsBtn = $("settingsBtn");
const settingsPanel = $("settingsPanel");
const closeSettingsBtn = $("closeSettingsBtn");
const themeSelect = $("themeSelect");
const fontSizeSelect = $("fontSizeSelect");
const wrapToggle = $("wrapToggle");
const toast = $("toast");
const noteModeBtn = $("noteModeBtn");
const codeModeBtn = $("codeModeBtn");
const previewModeBtn = $("previewModeBtn");
const markdownModeBtn = $("markdownModeBtn");
const htmlPreview = $("htmlPreview");
const markdownPreview = $("markdownPreview");
const modeHint = $("modeHint");
let editorMode = "note";

const DEFAULTS = {
  note: "",
  title: "",
  theme: "system",
  fontSize: 14,
  wrap: true,
  editorMode: "note"
};

let saveTimer = null;
let toastTimer = null;

function storageGet(keys) {
  return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
}

function storageSet(values) {
  return new Promise((resolve) => chrome.storage.local.set(values, resolve));
}

function storageRemove(keys) {
  return new Promise((resolve) => chrome.storage.local.remove(keys, resolve));
}

function updateStats(text) {
  const chars = text.length;
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  const lines = text ? text.split(/\r?\n/).length : 0;
  charCount.textContent = `${chars} ${chars === 1 ? "char" : "chars"}`;
  wordCount.textContent = `${words} ${words === 1 ? "word" : "words"}`;
  lineCount.textContent = `${lines} ${lines === 1 ? "line" : "lines"}`;
}

function setSaveState(state, label) {
  saveIndicator.dataset.state = state;
  saveText.textContent = label;
}

function queueSave() {
  setSaveState("saving", "Saving…");
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveNow, 300);
}

async function saveNow() {
  await storageSet({
    savedNote: noteInput.value,
    savedTitle: noteTitle.value,
    savedAt: Date.now()
  });
  setSaveState("saved", "Saved locally");
}

function applyTheme(theme) {
  document.body.dataset.theme = theme;
}

function applySettings() {
  noteInput.style.fontSize = `${Number(fontSizeSelect.value)}px`;
  noteInput.style.whiteSpace = wrapToggle.checked ? "pre-wrap" : "pre";
  noteInput.style.overflowX = wrapToggle.checked ? "hidden" : "auto";
  applyTheme(themeSelect.value);
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.remove("hidden");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.add("hidden"), 1800);
}

async function initialize() {
  const data = await storageGet([
    "savedNote", "savedTitle", "savedAt",
    "theme", "fontSize", "wrap", "editorMode"
  ]);

  noteInput.value = data.savedNote ?? DEFAULTS.note;
  noteTitle.value = data.savedTitle ?? DEFAULTS.title;
  themeSelect.value = data.theme ?? DEFAULTS.theme;
  fontSizeSelect.value = String(data.fontSize ?? DEFAULTS.fontSize);
  wrapToggle.checked = data.wrap ?? DEFAULTS.wrap;
  editorMode = data.editorMode ?? DEFAULTS.editorMode;

  updateStats(noteInput.value);
  applySettings();
  setEditorMode(editorMode, false);

  if (data.savedAt) {
    setSaveState("saved", "Saved locally");
  } else {
    setSaveState("saved", "Ready");
  }

  noteInput.focus();
}

async function savePreferences() {
  await storageSet({
    theme: themeSelect.value,
    fontSize: Number(fontSizeSelect.value),
    wrap: wrapToggle.checked,
    editorMode
  });
}

function setEditorMode(mode, persist = true) {
  editorMode = mode;
  const isPreview = mode === "preview";
  const isMarkdown = mode === "markdown";
  noteInput.classList.toggle("hidden", isPreview || isMarkdown);
  htmlPreview.classList.toggle("hidden", !isPreview);
  markdownPreview.classList.toggle("hidden", !isMarkdown);
  [noteModeBtn, codeModeBtn, previewModeBtn, markdownModeBtn].forEach((button) => {
    const active = button.dataset.mode === mode;
    button.classList.toggle("active", active);
    button.setAttribute("aria-pressed", String(active));
  });
  modeHint.textContent = mode === "note" ? "Plain text note · Markdown supported" : mode === "code" ? "Code editor · HTML and Markdown supported" : isPreview ? "Sandboxed HTML preview" : "Markdown preview · safe rendering";
  noteInput.spellcheck = mode === "note" || mode === "markdown";
  noteInput.placeholder = mode === "note"
    ? "Write a note… Markdown is supported. Use the Markdown button to preview."
    : "Write HTML, Markdown, CSS, JavaScript, or other code here…";
  if (isPreview) renderHtmlPreview();
  else if (isMarkdown) renderMarkdownPreview();
  else noteInput.focus();
  if (persist) storageSet({ editorMode: mode });
}

function escapeHtml(value) {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\"/g, "&quot;").replace(/'/g, "&#39;");
}

function renderMarkdown(source) {
  // Escape raw HTML first: Markdown preview never executes embedded HTML/scripts.
  let text = escapeHtml(source);
  const codeBlocks = [];
  text = text.replace(/```([\w-]*)\n([\s\S]*?)```/g, (_, lang, code) => {
    const token = `@@CODEBLOCK${codeBlocks.length}@@`;
    codeBlocks.push(`<pre><code class="language-${escapeHtml(lang || "text")}">${code.replace(/\n$/, "")}</code></pre>`);
    return token;
  });
  text = text.replace(/`([^`\n]+)`/g, "<code>$1</code>");
  text = text.replace(/^######\s+(.+)$/gm, "<h6>$1</h6>")
    .replace(/^#####\s+(.+)$/gm, "<h5>$1</h5>")
    .replace(/^####\s+(.+)$/gm, "<h4>$1</h4>")
    .replace(/^###\s+(.+)$/gm, "<h3>$1</h3>")
    .replace(/^##\s+(.+)$/gm, "<h2>$1</h2>")
    .replace(/^#\s+(.+)$/gm, "<h1>$1</h1>")
    .replace(/^>\s?(.+)$/gm, "<blockquote>$1</blockquote>")
    .replace(/^[-*]\s+(.+)$/gm, "<li>$1</li>")
    .replace(/(?:<li>.*?<\/li>\n?)+/gs, match => `<ul>${match}</ul>`)
    .replace(/^\s*---\s*$/gm, "<hr>")
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    .replace(/\[(.+?)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  text = text.split(/\n{2,}/).map(block => {
    const trimmed = block.trim();
    if (!trimmed || /^(<h[1-6]>|<ul>|<pre>|<blockquote>|<hr)/.test(trimmed) || /^@@CODEBLOCK\d+@@$/.test(trimmed)) return trimmed;
    return `<p>${trimmed.replace(/\n/g, "<br>")}</p>`;
  }).join("\n");
  return text.replace(/@@CODEBLOCK(\d+)@@/g, (_, i) => codeBlocks[Number(i)]);
}

function renderMarkdownPreview() {
  markdownPreview.innerHTML = renderMarkdown(noteInput.value || "# Markdown preview\n\nWrite **Markdown** in Note or Code mode, then switch here to preview it.");
}

function renderHtmlPreview() {
  // The iframe sandbox intentionally omits allow-scripts, so previewed HTML cannot run scripts.
  const source = noteInput.value;
  htmlPreview.srcdoc = source || "<!doctype html><html><body style='font:14px system-ui;padding:16px;color:#777'>Your HTML preview will appear here.</body></html>";
}

noteModeBtn.dataset.mode = "note";
codeModeBtn.dataset.mode = "code";
previewModeBtn.dataset.mode = "preview";
markdownModeBtn.dataset.mode = "markdown";
noteModeBtn.addEventListener("click", () => setEditorMode("note"));
codeModeBtn.addEventListener("click", () => setEditorMode("code"));
previewModeBtn.addEventListener("click", () => setEditorMode("preview"));
markdownModeBtn.addEventListener("click", () => setEditorMode("markdown"));

noteInput.addEventListener("input", () => {
  updateStats(noteInput.value);
  if (editorMode === "preview") renderHtmlPreview();
  if (editorMode === "markdown") renderMarkdownPreview();
  queueSave();
});

noteTitle.addEventListener("input", queueSave);

clearBtn.addEventListener("click", async () => {
  if (!noteInput.value && !noteTitle.value) return;
  noteInput.value = "";
  noteTitle.value = "";
  updateStats("");
  await storageRemove(["savedNote", "savedTitle", "savedAt"]);
  setSaveState("saved", "Cleared");
  noteInput.focus();
  showToast("Note cleared");
});

exportBtn.addEventListener("click", () => {
  const title = noteTitle.value.trim() || "quick-note";
  const body = noteTitle.value.trim()
    ? `${noteTitle.value.trim()}\n\n${noteInput.value}`
    : noteInput.value;
  const blob = new Blob([body], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  const extension = editorMode === "markdown" ? "md" : (editorMode === "code" || editorMode === "preview") ? "html" : "txt";
  a.download = `${title.replace(/[\\/:*?"<>|]/g, "-")}.${extension}`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  showToast("Note exported");
});

importBtn.addEventListener("click", () => fileInput.click());

fileInput.addEventListener("change", async () => {
  const file = fileInput.files?.[0];
  if (!file) return;

  const raw = await file.text();
  let text = raw;
  if (/\.ght$/i.test(file.name)) {
    try {
      const project = JSON.parse(raw);
      if (project.format !== "GHT") throw new Error("Not a GHT project");
      text = String(project.note || "");
      noteTitle.value = String(project.title || file.name.replace(/\.ght$/i, ""));
      showToast("GHT project imported");
    } catch {
      showToast("Invalid .GHT project");
      fileInput.value = "";
      return;
    }
  } else {
    noteTitle.value = file.name.replace(/\.(txt|md)$/i, "");
    showToast("Note imported");
  }
  noteInput.value = text;
  if (/\.md$/i.test(file.name)) { editorMode = "note"; setEditorMode("note"); }
  updateStats(text);
  await saveNow();
  fileInput.value = "";
});

function openSearch() {
  searchBar.classList.remove("hidden");
  searchInput.focus();
  searchInput.select();
  updateSearch();
}

function closeSearch() {
  searchBar.classList.add("hidden");
  searchInput.value = "";
  searchCount.textContent = "0 matches";
  noteInput.focus();
}

function updateSearch() {
  const query = searchInput.value.trim().toLowerCase();
  if (!query) {
    searchCount.textContent = "0 matches";
    return;
  }
  const text = noteInput.value.toLowerCase();
  let count = 0;
  let index = 0;
  while ((index = text.indexOf(query, index)) !== -1) {
    count++;
    index += query.length;
  }
  searchCount.textContent = `${count} ${count === 1 ? "match" : "matches"}`;
}

searchBtn.addEventListener("click", openSearch);
closeSearchBtn.addEventListener("click", closeSearch);
searchInput.addEventListener("input", updateSearch);

settingsBtn.addEventListener("click", () => {
  settingsPanel.classList.toggle("hidden");
});
closeSettingsBtn.addEventListener("click", () => {
  settingsPanel.classList.add("hidden");
});

themeSelect.addEventListener("change", async () => {
  applySettings();
  await savePreferences();
});

fontSizeSelect.addEventListener("change", async () => {
  applySettings();
  await savePreferences();
});

wrapToggle.addEventListener("change", async () => {
  applySettings();
  await savePreferences();
});

document.addEventListener("keydown", (event) => {
  const modifier = event.ctrlKey || event.metaKey;

  if (modifier && event.key.toLowerCase() === "s") {
    event.preventDefault();
    saveNow().then(() => showToast("Saved"));
  }

  if (modifier && event.key.toLowerCase() === "f") {
    event.preventDefault();
    openSearch();
  }

  if (event.key === "Escape") {
    if (!searchBar.classList.contains("hidden")) closeSearch();
    else if (!settingsPanel.classList.contains("hidden")) settingsPanel.classList.add("hidden");
  }
});

initialize();

// H2.7 Side Update: Notepad Azure, .GHT projects, AI Azure, collaboration-ready export.
const ghtBtn = $("ghtBtn");
const aiBtn = $("aiBtn");
const aiPanel = $("aiPanel");
const closeAiBtn = $("closeAiBtn");
const collabBtn = $("collabBtn");
const collabPanel = $("collabPanel");
const closeCollabBtn = $("closeCollabBtn");
const shareGhtBtn = $("shareGhtBtn");
const aiOutput = $("aiOutput");
const collabStatus = $("collabStatus");

function downloadBlob(name, blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 0);
}

async function createGht() {
  const project = {
    format: "GHT",
    version: 1,
    application: "Notepad Azure",
    update: "H2.7",
    title: noteTitle.value.trim() || "Untitled note",
    note: noteInput.value,
    createdAt: new Date().toISOString(),
    collaboration: { ready: true, mode: "local-first" }
  };
  // A portable .GHT is a UTF-8 project manifest. It is intentionally plain data,
  // making it safe to inspect and easy to evolve in later H3 releases.
  const payload = JSON.stringify(project, null, 2);
  const filename = (noteTitle.value.trim() || "notepad-azure-project")
    .replace(/[\\/:*?"<>|]/g, "-") + ".ght";
  downloadBlob(filename, new Blob([payload], {type:"application/json;charset=utf-8"}));
  showToast(".GHT project exported");
}

ghtBtn?.addEventListener("click", createGht);
shareGhtBtn?.addEventListener("click", async () => {
  await createGht();
  collabStatus.textContent = "Project package created. Share the .GHT file with a collaborator.";
});

aiBtn?.addEventListener("click", () => {
  aiPanel.classList.remove("hidden"); collabPanel.classList.add("hidden");
});
closeAiBtn?.addEventListener("click", () => aiPanel.classList.add("hidden"));
collabBtn?.addEventListener("click", () => {
  renderTabOptions();
  tabSelect?.focus();
  showToast(`Tabs: ${noteTabs.length}/120`);
});
closeCollabBtn?.addEventListener("click", () => collabPanel.classList.add("hidden"));

document.querySelectorAll(".ai-action").forEach(btn => btn.addEventListener("click", () => {
  const text = noteInput.value.trim();
  if (!text) { aiOutput.textContent = "Write something first, then run an AI Azure tool."; return; }
  const mode = btn.dataset.ai;
  if (mode === "summarize") {
    const sentences = text.split(/(?<=[.!?])\s+/).filter(Boolean);
    aiOutput.textContent = "Summary (local H2.7): " + sentences.slice(0, 2).join(" ");
  } else if (mode === "polish") {
    aiOutput.textContent = "Polish preview (local):\n" + text.replace(/\s+/g, " ").trim();
  } else {
    const lines = text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
    aiOutput.textContent = "Outline:\\n" + lines.slice(0, 8).map((x,i)=>`${i+1}. ${x}`).join("\n");
  }
}));

// 3VS Major Update: multi-tab notes, local published gallery, templates, and quality preference.
const tabSelect = $("tabSelect");
const newTabBtn = $("newTabBtn");
const showTabsBtn = $("showTabsBtn");
const publishBtn = $("publishBtn");
const galleryList = $("galleryList");
const qualitySelect = $("qualitySelect");
const templateSelect = $("templateSelect");
let noteTabs = [];
let activeTabId = "main";
let tabsReady = false;

function currentTabSnapshot() {
  return { id: activeTabId, title: noteTitle.value, note: noteInput.value, editorMode };
}
function renderTabOptions() {
  if (!tabSelect) return;
  tabSelect.replaceChildren();
  noteTabs.forEach((tab, index) => {
    const option = document.createElement("option");
    option.value = tab.id;
    option.textContent = `${index + 1}. ${(tab.title || "Untitled note").slice(0, 28)}`;
    tabSelect.appendChild(option);
  });
  tabSelect.value = activeTabId;
  if (newTabBtn) newTabBtn.disabled = noteTabs.length >= 120;
  if (showTabsBtn) showTabsBtn.textContent = `Show Tabs (${noteTabs.length}/120)`;
}
async function persistTabs() {
  if (!tabsReady) return;
  const idx = noteTabs.findIndex(t => t.id === activeTabId);
  if (idx >= 0) noteTabs[idx] = currentTabSnapshot();
  await storageSet({ noteTabs, activeTabId });
  renderTabOptions();
}
async function activateTab(id) {
  const idx = noteTabs.findIndex(t => t.id === id);
  if (idx < 0) return;
  const currentIndex = noteTabs.findIndex(t => t.id === activeTabId);
  if (currentIndex >= 0) noteTabs[currentIndex] = currentTabSnapshot();
  activeTabId = id;
  const tab = noteTabs[idx];
  noteTitle.value = tab.title || "";
  noteInput.value = tab.note || "";
  updateStats(noteInput.value);
  setEditorMode(tab.editorMode || "note", false);
  await storageSet({ savedNote: noteInput.value, savedTitle: noteTitle.value, editorMode, activeTabId, noteTabs });
  renderTabOptions();
  setSaveState("saved", "Saved locally");
}
async function initializeTabs() {
  const data = await storageGet(["noteTabs", "activeTabId", "quality"]);
  noteTabs = Array.isArray(data.noteTabs) ? data.noteTabs.slice(0, 120) : [];
  activeTabId = data.activeTabId || "main";
  if (!noteTabs.length) noteTabs = [{ id: "main", title: noteTitle.value || "Untitled note", note: noteInput.value || "", editorMode }];
  if (!noteTabs.some(t => t.id === activeTabId)) activeTabId = noteTabs[0].id;
  qualitySelect.value = data.quality || "1080p";
  tabsReady = true;
  const active = noteTabs.find(t => t.id === activeTabId);
  if (active) {
    noteTitle.value = active.title || "";
    noteInput.value = active.note || "";
    updateStats(noteInput.value);
    setEditorMode(active.editorMode || "note", false);
  }
  renderTabOptions();
}
newTabBtn?.addEventListener("click", async () => {
  await persistTabs();
  if (noteTabs.length >= 120) { showToast("Maximum of 120 tabs reached"); return; }
  const id = `tab-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  noteTabs.push({ id, title: "Untitled note", note: "", editorMode: "note" });
  activeTabId = id;
  noteTitle.value = ""; noteInput.value = ""; setEditorMode("note", false); updateStats("");
  await storageSet({ noteTabs, activeTabId, savedNote: "", savedTitle: "" });
  renderTabOptions(); noteInput.focus(); showToast("New tab created");
});
tabSelect?.addEventListener("change", () => activateTab(tabSelect.value));
showTabsBtn?.addEventListener("click", () => {
  renderTabOptions();
  showToast(`Showing ${noteTabs.length} of 120 tabs`);
  tabSelect?.focus();
});
noteInput.addEventListener("input", () => { if (tabsReady) persistTabs(); });
noteTitle.addEventListener("input", () => { if (tabsReady) persistTabs(); });

const templateContent = {
  lorem: { title: "Lorem Ipsum", text: "# Lorem Ipsum\n\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.\n\n## Notes\n- First point\n- Second point\n" },
  "2006": { title: "2006 Text Style", text: "[ 2006 ]\n\nWelcome to my page!!!\n------------------------------\nType your text here...\n\n~*~ My Notes ~*~\n" },
  "2010": { title: "2010 Text Style", text: "✦ Welcome ✦\n\nHey there! Thanks for visiting my notes.\n\n★ About this page\nWrite your text here and make it yours.\n\n— Updated 2010 style —\n" }
};
templateSelect?.addEventListener("change", async () => {
  const template = templateContent[templateSelect.value];
  if (!template) return;
  if (noteInput.value.trim() && !confirm("Replace the current note with this template?")) { templateSelect.value = ""; return; }
  noteTitle.value = template.title; noteInput.value = template.text; setEditorMode("note"); updateStats(noteInput.value); queueSave();
  await persistTabs(); templateSelect.value = ""; showToast("Template applied");
});
qualitySelect?.addEventListener("change", async () => {
  await storageSet({ quality: qualitySelect.value });
  showToast(`Text quality set to ${qualitySelect.value}`);
});
async function renderGallery() {
  if (!galleryList) return;
  const data = await storageGet(["publishedNotes"]);
  const items = Array.isArray(data.publishedNotes) ? data.publishedNotes : [];
  galleryList.replaceChildren();
  if (!items.length) { galleryList.textContent = "No published notes yet. Use Publish to add this note."; return; }
  items.slice().reverse().forEach(item => {
    const card = document.createElement("div"); card.className = "gallery-item";
    const title = document.createElement("strong"); title.textContent = item.title || "Untitled note";
    const preview = document.createElement("p"); preview.textContent = (item.note || "").slice(0, 160);
    const open = document.createElement("button"); open.className = "btn btn-ghost"; open.textContent = "Open";
    open.addEventListener("click", () => { noteTitle.value = item.title || ""; noteInput.value = item.note || ""; setEditorMode(item.editorMode || "note"); updateStats(noteInput.value); queueSave(); showToast("Published note opened"); });
    card.append(title, preview, open); galleryList.appendChild(card);
  });
}
publishBtn?.addEventListener("click", async () => {
  const data = await storageGet(["publishedNotes"]);
  const items = Array.isArray(data.publishedNotes) ? data.publishedNotes : [];
  items.push({ id: `pub-${Date.now()}`, title: noteTitle.value.trim() || "Untitled note", note: noteInput.value, editorMode, publishedAt: new Date().toISOString() });
  await storageSet({ publishedNotes: items.slice(-200) });
  await renderGallery();
  collabPanel?.classList.remove("hidden"); aiPanel?.classList.add("hidden");
  if (collabStatus) collabStatus.textContent = "Published to this browser's local gallery. It is not uploaded to a public website.";
  showToast("Published to local gallery");
});

initializeTabs();
